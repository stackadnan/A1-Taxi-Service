@extends('layouts.admin')

@section('title', 'Accounts')

@section('content')
<div class="bg-white p-6 rounded shadow">
  <h1 class="text-2xl font-semibold mb-4">Accounts</h1>
  <p class="text-gray-600">Placeholder for Accounts.</p>
</div>
@endsection
