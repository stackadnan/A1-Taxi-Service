@extends('layouts.admin')

@section('title', 'Reviews & Concerns')

@section('content')
<div class="bg-white p-6 rounded shadow">
  <h1 class="text-2xl font-semibold mb-4">Reviews / Concerns</h1>
  <p class="text-gray-600">Placeholder for handling user reviews and concerns.</p>
</div>
@endsection
