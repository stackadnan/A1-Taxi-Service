@extends('layouts.admin')

@section('title', 'Settings')

@section('content')
<div class="bg-white p-6 rounded shadow">
  <h1 class="text-2xl font-semibold mb-4">Admin Settings</h1>
  <p class="text-gray-600">Placeholder for admin settings (general site configuration).</p>
</div>
@endsection
