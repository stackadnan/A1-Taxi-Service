<div id="zone-edit-controls" style="display:none" class="inline-flex gap-2">
  <button id="zone-edit-save" class="px-3 py-2 bg-green-600 text-white rounded">Save</button>
  <button id="zone-edit-cancel" class="px-3 py-2 bg-gray-500 text-white rounded">Cancel</button>
</div>