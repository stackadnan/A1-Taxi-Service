<option value="{{ $zone->id }}">{{ $zone->zone_name }}</option>
