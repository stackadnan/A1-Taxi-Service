@extends('layouts.admin')

@section('title', 'Notifications')

@section('content')
<div class="bg-white p-6 rounded shadow">
  <h1 class="text-2xl font-semibold mb-4">Notification Settings</h1>
  <p class="text-gray-600">Placeholder for notification channels and templates.</p>
</div>
@endsection
