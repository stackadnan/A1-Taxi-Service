<?php $isEdit = isset($driver) && $driver->id; ?>
<form id="driver-form" method="POST" action="<?php echo e($isEdit ? route('admin.drivers.update', $driver) : route('admin.drivers.store')); ?>">
  <?php echo csrf_field(); ?>
  <?php if($isEdit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

  <div class="grid grid-cols-2 gap-4">
    <div>
      <label class="block text-sm font-medium text-gray-700">Name</label>
      <input type="text" name="name" value="<?php echo e(old('name', $driver->name ?? '')); ?>" class="mt-1 block w-full border rounded p-2" required>
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Phone</label>
      <input type="text" name="phone" value="<?php echo e(old('phone', $driver->phone ?? '')); ?>" class="mt-1 block w-full border rounded p-2">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Email</label>
      <input type="email" name="email" value="<?php echo e(old('email', $driver->email ?? '')); ?>" class="mt-1 block w-full border rounded p-2">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Vehicle Plate</label>
      <input type="text" name="vehicle_plate" value="<?php echo e(old('vehicle_plate', $driver->vehicle_plate ?? '')); ?>" class="mt-1 block w-full border rounded p-2">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Make</label>
      <input type="text" name="vehicle_make" value="<?php echo e(old('vehicle_make', $driver->vehicle_make ?? '')); ?>" class="mt-1 block w-full border rounded p-2">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Model</label>
      <input type="text" name="vehicle_model" value="<?php echo e(old('vehicle_model', $driver->vehicle_model ?? '')); ?>" class="mt-1 block w-full border rounded p-2">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Coverage Area</label>
      <input type="text" name="coverage_area" value="<?php echo e(old('coverage_area', $driver->coverage_area ?? '')); ?>" class="mt-1 block w-full border rounded p-2" placeholder="e.g., Heathrow, Zone 1">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Badge Number</label>
      <input type="text" name="badge_number" value="<?php echo e(old('badge_number', $driver->badge_number ?? '')); ?>" class="mt-1 block w-full border rounded p-2">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Car type</label>
      <input type="text" name="car_type" value="<?php echo e(old('car_type', $driver->car_type ?? '')); ?>" class="mt-1 block w-full border rounded p-2" placeholder="e.g., Saloon, MPV6">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Car color</label>
      <input type="text" name="car_color" value="<?php echo e(old('car_color', $driver->car_color ?? '')); ?>" class="mt-1 block w-full border rounded p-2" placeholder="e.g., Black / Green">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Time slot</label>
      <input type="text" name="time_slot" value="<?php echo e(old('time_slot', $driver->time_slot ?? '')); ?>" class="mt-1 block w-full border rounded p-2" placeholder="e.g., 24/7, 9-5">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Password</label>
      <input type="password" name="password" class="mt-1 block w-full border rounded p-2" autocomplete="new-password">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Confirm Password</label>
      <input type="password" name="password_confirmation" class="mt-1 block w-full border rounded p-2" autocomplete="new-password">
    </div>

    <div>
      <label class="block text-sm font-medium text-gray-700">Status</label>
      <select name="status" class="mt-1 block w-full border rounded p-2">
        <option value="active" <?php echo e((old('status', $driver->status ?? '')=='active') ? 'selected' : ''); ?>>Active</option>
        <option value="inactive" <?php echo e((old('status', $driver->status ?? '')=='inactive') ? 'selected' : ''); ?>>Inactive</option>
        <option value="suspended" <?php echo e((old('status', $driver->status ?? '')=='suspended') ? 'selected' : ''); ?>>Suspended</option>
      </select>
    </div>
  </div>

  <div class="mt-4 flex items-center gap-2">
    <button class="px-4 py-2 bg-indigo-600 text-white rounded">Save</button>
    <button type="button" data-action="close-modal" class="ml-2 px-4 py-2 border rounded">Cancel</button>
  </div>
</form><?php /**PATH C:\xampp\htdocs\AirportServices\resources\views/admin/drivers/_modal_form.blade.php ENDPATH**/ ?>