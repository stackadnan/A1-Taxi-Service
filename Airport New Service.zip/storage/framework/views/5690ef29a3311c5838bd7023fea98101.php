

<?php $__env->startSection('title', 'Bookings'); ?>

<?php $__env->startSection('content'); ?>
<style>
  /* Prevent hover effects on active tabs only, not buttons */
  /* ul[role="tablist"] a.bg-indigo-200.text-white:hover {
    background-color: rgb(79 70 229) !important;
    color: white !important;
    border-color: rgb(79 70 229) !important;
  } */
</style>
<div class="bg-white p-6 rounded shadow">
  <div class="flex justify-between items-center mb-4">
    <h1 class="text-2xl font-semibold">Bookings</h1>
    <a href="<?php echo e(route('admin.bookings.index', array_merge(request()->except('page'), ['section' => 'new_manual']))); ?>" 
       class="px-4 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700 transition-all shadow-md hover:shadow-lg flex items-center gap-2"
       data-tab="new_manual">
      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
      </svg>
      Generate Booking
    </a>
  </div>

  <div class="mb-4">
    <ul class="flex flex-wrap gap-3" role="tablist">
      <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($key !== 'new_manual'): ?>
          <?php $isActive = ($key === $active); ?>
          <li>
            <a href="<?php echo e(route('admin.bookings.index', array_merge(request()->except('page'), ['section' => $key]))); ?>" class="px-4 py-2 rounded-lg border text-sm font-medium focus:outline-none transition-all <?php echo e($isActive ? 'border-indigo-600 shadow-md' : 'bg-white text-gray-700 border-gray-300 hover:bg-indigo-50 hover:border-indigo-500 hover:text-indigo-700 hover:shadow-sm'); ?>" data-tab="<?php echo e($key); ?>">
              <?php echo e($label); ?>

              <span class="ml-2 inline-block <?php echo e($isActive ? '' : 'bg-gray-100 text-gray-700'); ?> text-xs px-2 py-0.5 rounded"><?php echo e($counts[$key] ?? 0); ?></span>
            </a>
          </li>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>

  <div id="bookings-tabs">
    <?php $keys = array_keys($sections); ?>

    <?php $__currentLoopData = $keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $isActivePane = ($key === $active); ?>
      <section data-pane="<?php echo e($key); ?>" class="<?php echo e($isActivePane ? 'tab-pane' : 'hidden tab-pane'); ?>">
        <h2 class="text-lg font-semibold mb-2"><?php echo e($sections[$key]); ?></h2>
        <div id="booking-<?php echo e($key); ?>-container">
          <div class="text-gray-600">Loading <?php echo e($sections[$key]); ?>…</div>
        </div>
      </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <script>
  (function(){
    // Generic helpers
    function runInjectedScripts(container){
      try {
        var scripts = container.querySelectorAll('script');
        scripts.forEach(function(s){
          var ns = document.createElement('script');
          if (s.src) {
            ns.src = s.src; ns.async = false; document.head.appendChild(ns);
            ns.onload = function(){ console.debug('Loaded injected script', s.src); };
            ns.onerror = function(e){ console.error('Injected script failed to load', s.src, e); };
          } else {
            ns.text = s.textContent; document.head.appendChild(ns);
          }
          s.parentNode.removeChild(s);
        });
      } catch(e) { console.error('runInjectedScripts error', e); }
    }
    // Expose globally for modal responses
    if (typeof window.runInjectedScripts === 'undefined') window.runInjectedScripts = runInjectedScripts;

    function attachPagination(container){
      var links = container.querySelectorAll('.pagination a');
      links.forEach(function(a){
        if (a.dataset.ajaxAttached) return; a.dataset.ajaxAttached = '1';
        a.addEventListener('click', function(e){
          e.preventDefault();
          var href = a.getAttribute('href');
          if (!href) return;
          fetch(href + (href.indexOf('?') === -1 ? '?' : '&') + 'partial=1', { headers: { 'X-Requested-With': 'XMLHttpRequest' }, credentials: 'same-origin' }).then(function(r){ return r.text(); }).then(function(html){ container.innerHTML = html; runInjectedScripts(container); attachPagination(container); attachRowHandlers(container); }).catch(function(err){ console.error('Pagination load failed', err); });
        });
      });
    }

    function attachRowHandlers(container){
      // rows should have data-booking-id attributes in partial view; attach click handler if present
      var rows = container.querySelectorAll('[data-booking-id]');
      rows.forEach(function(r){ if (r.dataset.rowBound) return; r.dataset.rowBound = '1'; r.addEventListener('click', function(){ var id = r.getAttribute('data-booking-id'); if (!id) return; window.location.href = '/admin/bookings/' + id; }); });
    }

    // Load a single booking pane via AJAX partial
    function loadSection(key){
      var container = document.getElementById('booking-' + key + '-container');
      if (!container) return Promise.resolve();
      if (container.dataset.loaded) return Promise.resolve();
      container.innerHTML = '<div class="p-4 text-gray-600">Loading…</div>';
      var url = '<?php echo e(route('admin.bookings.index')); ?>?partial=1&section=' + encodeURIComponent(key);
      return fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, credentials: 'same-origin' }).then(function(res){ if (!res.ok) return res.text().then(function(t){ throw new Error('Failed to load: ' + res.status + '\n' + t.slice(0,200)); }); return res.text(); }).then(function(html){ container.innerHTML = html; container.dataset.loaded = '1'; runInjectedScripts(container); attachPagination(container); attachRowHandlers(container); return Promise.resolve(); }).catch(function(err){ console.error('Load section '+key+' error', err); container.innerHTML = '<div class="text-red-600">Failed to load. <button id="retry-'+key+'" class="ml-2 px-2 py-1 border rounded">Retry</button></div>'; var btn = document.getElementById('retry-'+key); if (btn) btn.addEventListener('click', function(){ loadSection(key); }); return Promise.resolve(); });
    }

    // preload all sections on first load, then hide via CSS (so switching is instant)
    var sections = <?php echo json_encode(array_keys($sections), 15, 512) ?>;
    Promise.all(sections.map(function(k){ return loadSection(k); })).then(function(){ console.debug('All booking sections loaded'); }).catch(function(){ console.warn('Some booking sections failed to load'); });

    // Tab activation (show/hide panes similar to pricing)
    var tabs = document.querySelectorAll('ul[role="tablist"] [data-tab]');
    var panes = document.querySelectorAll('[data-pane]');
    function activate(tabName){
      tabs.forEach(function(t){
        if(t.getAttribute('data-tab') === tabName){
          t.classList.add('border-indigo-600','text-indigo-700');
          t.classList.remove('text-gray-700');
          t.setAttribute('aria-selected','true');
        } else {
          t.classList.remove('border-indigo-600','text-indigo-700');
          t.classList.add('text-gray-700');
          t.setAttribute('aria-selected','false');
        }
      });
      panes.forEach(function(p){ if(p.getAttribute('data-pane') === tabName) p.classList.remove('hidden'); else p.classList.add('hidden'); });
      // update querystring (so links remain meaningful)
      try { history.replaceState(null, '', '?section=' + tabName); } catch(e){}
    }

    tabs.forEach(function(t){ t.addEventListener('click', function(e){ e.preventDefault(); activate(t.getAttribute('data-tab')); }); });

    // Handle New Manual Booking button (it uses an anchor outside tab list)
    var manualBtn = document.querySelector('[data-tab="new_manual"]');
    // keep track of last non-manual active tab so we can return to it when toggling
    var lastNonManualTab = '<?php echo e($active); ?>' === 'new_manual' ? (function(){ var t = document.querySelector('ul[role="tablist"] [data-tab]'); return t ? t.getAttribute('data-tab') : null; })() : '<?php echo e($active); ?>';

    if (manualBtn) manualBtn.addEventListener('click', function(e){
      e.preventDefault();
      var activePane = document.querySelector('[data-pane]:not(.hidden)');
      var activeName = activePane ? activePane.getAttribute('data-pane') : null;

      if (activeName === 'new_manual') {
        // currently visible -> toggle hide: return to last non-manual tab if we have one
        if (lastNonManualTab && lastNonManualTab !== 'new_manual') {
          activate(lastNonManualTab);
        } else {
          // fallback: activate first available tab (non-manual)
          var firstTab = document.querySelector('ul[role="tablist"] [data-tab]');
          if (firstTab) {
            activate(firstTab.getAttribute('data-tab'));
          } else {
            // hide manual pane only
            var pane = document.querySelector('[data-pane="new_manual"]');
            if (pane) pane.classList.add('hidden');
          }
        }
      } else {
        // store last non-manual tab and show manual pane
        if (activeName && activeName !== 'new_manual') lastNonManualTab = activeName;
        activate('new_manual');
      }
    });

    // Set initial visibility based on server-provided active
    activate('<?php echo e($active); ?>');
  })();
  </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AirportServices\resources\views/admin/bookings/index.blade.php ENDPATH**/ ?>