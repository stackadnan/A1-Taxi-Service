

<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded shadow">
  <h1 class="text-2xl font-semibold mb-4">Notification Settings</h1>
  <p class="text-gray-600">Placeholder for notification channels and templates.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\AirportServices\resources\views/admin/notifications/index.blade.php ENDPATH**/ ?>