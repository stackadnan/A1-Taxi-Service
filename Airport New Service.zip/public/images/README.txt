Place your logo image here so the admin login uses it as the site logo.

Filename (recommended): aero-cab-logo.png
Path: public/images/aero-cab-logo.png

If you need a specific size, we recommend ~96x96 to 192x192 pixels (PNG or SVG).

After adding the image, refresh the admin login page: http://localhost:8000/admin/login
